import os
from textblob import TextBlob
import time
loc = "Object_casedocs/"
l = os.listdir(loc)

with open("till.txt") as till:
    n = int(till.read())
l = sorted(l, key = lambda x: int(x[1:-4]))[n]
doneKB = 1  # should have been 0
todo = sum([os.path.getsize(loc+x) for x in l])
print("total size to be done =", todo/(1024**2), "MB")
t00 = time.time()
for i, file in enumerate(l):
    fn = loc + file
    print(f"Doing: {file}")
    t0 = time.time()
    doneKB += os.path.getsize(fn)
    with open(fn) as f:
        t = TextBlob(f.read())
    s = str(t.correct())
    with open(fn, "w") as f:
        f.write(s)
    
    t1 = time.time()
    i+=1
    print(f"took {(t1-t0)} seconds for this {os.path.getsize(fn)}KB file") ######
    # print(f"average time taken per file = {((t1-t00)/i)} seconds") ######
    print(f"average time taken per kb = {((t1-t00)/(doneKB/1024))} seconds") ######
    print(f"percentage done = {doneKB*100/todo}%") ######
    print(f"estimated time remaining = {todo*(t1-t00)/(doneKB*60)} mins = {todo*(t1-t00)/(doneKB*3600)} hours") ######
    print(f"total elapsed time = {(t1-t00)/60} mins\n") ######
    with open("till.txt", "w") as till:
        till.write(file[1:-4])