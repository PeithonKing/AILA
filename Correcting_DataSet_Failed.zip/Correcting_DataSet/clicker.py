import pyautogui as p
from time import sleep

print("Starting in 5s")
sleep(5)
print("Starting Now")

for i in range(1000):
    sleep(0.5)
    try: p.click("Accept.png")
    except TypeError: pass